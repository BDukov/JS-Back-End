exports.SECRET = 'my secret';
exports.TOKEN_KEY = 'token';